#!/bin/sh

	# config bonding before wlan config, or wlan wouldn't work ??
DEV=adm0
WLAN_DEV=ra0
wlan_exist=0

start() {
	if [ $wlan_exist = 1 ] ; then
	/sbin/ifconfig $DEV up
	/sbin/ifconfig $WLAN_DEV up
	/sbin/ifconfig bond0 up
	/sbin/ifenslave -E bond0 $DEV
	/sbin/ifenslave -E bond0 $WLAN_DEV
	/sbin/route add -host 255.255.255.255 bond0
	else
	/sbin/route add -host 255.255.255.255 $DEV
	fi
	# start the streaming server again
	/etc/init.d/streaming start
}

stop() {
	/bin/kill `pidof video_svr`
	retry=3
	while [ "$retry" -gt 0 ]
	do
		pp=`pidof video_svr`
		if [ -z "$pp" ] ; then
			echo "video svr killed"
			break;
		fi
		retry=$(($retry -1))
		sleep 1
	done
	if [ $wlan_exist = 0 ] ; then
		exit 0
	fi
	/sbin/ifconfig bond0 down
	/sbin/ifconfig $DEV down
	/sbin/ifconfig $WLAN_DEV down
	/sbin/ifconfig bond0 hw ether 000000000000
}

/sbin/get_wlan
wlan_exist=$?

case "$1" in
	start)
		start
		;;
	stop)
		stop
		;;
	restart)
		restart
		;;
	*)
		echo $"Usage $0 {start|stop|restart}"
		exit 1
esac

exit $?
