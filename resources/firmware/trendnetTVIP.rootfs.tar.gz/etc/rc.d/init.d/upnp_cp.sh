
#!  /bin./bash

wan_service="IP"
port=`/sbin/hgcfg -o get -p /etc net.conf WAN "Http Port"`
model=`/sbin/hgcfg -o get -p /etc sys.conf SYSTEM "CameraName"`

upnp_portmap()
{
	# query the port is available
	/sbin/UPnP_CP $1 0 $2 TCP
	retval=$?
	if [ $retval = 202 ]; then # ret is 714 - (256*2) = 202:)
		# the port is empty, set port map now!
		/sbin/UPnP_CP $1 1 $2 TCP 1 $3 $2
		exit $?
	fi
	exit $retval
}


if [ -z $model ]; then
	model=`/sbin/hgcfg -o get -p /etc info.conf INFO "ModelName"`
fi

# use IP conn first 
/sbin/UPnP_CP IP 2

if [ $? = 0 ] ; then
	upnp_portmap $wan_service $port $model
else
	# use PPP conn 
	/sbin/UPnP_CP PPP 2
	if [ $? = 0 ] ; then
		wan_service="PPP"
		upnp_portmap $wan_service $port $model
	else
		echo "No UPnP port-mapping support"
		exit 255
	fi
fi
exit 0
