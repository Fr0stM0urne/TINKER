#!/bin/sh

DEV=`/sbin/hgcfg -o get -p /etc net.conf NETWORK "Wan Dev"`
BONDING=`/sbin/hgcfg -o get -p /etc net.conf NETWORK "bonding"`
hostname=`/sbin/hgcfg -o get -p /etc sys.conf SYSTEM CameraName`
modelname=`/sbin/hgcfg -o get -p /etc info.conf INFO ModelName`

checkpid() {
	local i

	for i in $*; do
		[ -d "/proc/$i" ] || return 1
	done
	return 0
}

wlan_start() {
	gw=`/sbin/iff_get -g bond0`
	netmask=`/sbin/iff_get -m bond0`
	/sbin/ifconfig bond0 down
	/sbin/ifconfig bond0 up
	/sbin/ifenslave -E bond0 adm0
	/sbin/ifenslave -E bond0 ra0

	# run the region(country) code
	/sbin/raconfig2 get flash_reg
	region=$?
	if [ $region -ge 0 ] ; then
		echo "set region(country) code:$region"
		/sbin/raconfig2 region $region
	fi
	# startup the wlan device
	/sbin/wlan_boot

	/sbin/route add default gw $gw bond0
	DEV=bond0
}

start() {

	if [ $BONDING = 1 ]; then
		DEV=bond0
#		iwconfig ra0
	fi
	if [ -z $hostname ]; then
		#use default model name as default
		hostname=$modelname
	fi

	retry=3
	while [ "$retry" -gt 0 ]
	do
		/sbin/ifconfig $DEV > /dev/urandom
#		/sbin/udhcpc -b -i $DEV -p /var/run/udhcpc.pid 
		/sbin/udhcpc -n -i $DEV -p /var/run/udhcpc.pid 
		if [ $? = 0 ]; then
			break
		fi
		retry=$(($retry -1))
		sleep 3
	done
	if [ $retry = 0 ]; then
		/sbin/ifconfig $DEV 192.168.0.30 netmask 255.255.255.0
		if [ $BONDING = 1 ]; then
			/sbin/ifconfig bond0 down
			/sbin/ifconfig bond0 up
			/sbin/ifenslave -E bond0 adm0
			/sbin/ifenslave -E bond0 ra0

			# run the region(country) code
			/sbin/raconfig2 get flash_reg
			region=$?
			if [ $region -ge 0 ] ; then
				echo "set region(country) code:$region"
				/sbin/raconfig2 region $region
			fi
			/sbin/wlan_boot

			DEV=bond0
		fi
		/sbin/route add default gw 192.168.0.1
		exit 1
	else
		# try to keep request dhcp server if fail to get ip
		/bin/kill `pidof udhcpc`
		/sbin/udhcpc -i $DEV -p /var/run/udhcpc.pid 
		if [ $? = 0 ]; then
			if [ $BONDING = 1 ]; then
				wlan_start
			else
				DEV=adm0
			fi
		fi
		exit 0
	fi
}

killproc() {
	pid=
	if [ -f /var/run/$1.pid ]; then
		local line p
		read line < /var/run/$1.pid
		kill -9 $line
	fi
	rm -f /var/run/$1.pid
}

stop() {
	killproc udhcpc
}	

restart() {
	stop
	start
}

case "$1" in
	start)
		start
		;;
	stop)
		stop
		;;
	restart)
		restart
		;;
	*)
		echo $"Usage $0 {start|stop|restart}"
		exit 1
esac

exit $?
