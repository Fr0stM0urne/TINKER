#!/bin/sh

# get wlan configuration
wlan_mode=`/sbin/hgcfg -o get -p /etc net.conf WLAN Mode`
wlan_essid=`/sbin/hgcfg -o get -p /etc net.conf WLAN ESSID`
wlan_channel=`/sbin/hgcfg -o get -p /etc net.conf WLAN Channel`
wlan_enc=`/sbin/hgcfg -o get -p /etc net.conf WLAN Encryption`
wlan_format=`/sbin/hgcfg -o get -p /etc net.conf WLAN "Key Format"`
wlan_key=`/sbin/hgcfg -o get -p /etc net.conf WLAN Key`
wlan_key_id=`/sbin/hgcfg -o get -p /etc net.conf WLAN KeyID`

wlan_connect()
{
	if [ $wlan_mode = 1 ]; then
		/usr/sbin/iwconfig $WLAN_DEV essid $wlan_essid mode Ad-Hoc channel $wlan_channel enc off
	elif [ $wlan_mode = 0 ]; then
		/sbin/raconfig set $wlan_essid open
	fi
	if [ $wlan_enc != 0 ]; then
		if [ $wlan_enc = 1 ]; then 
			# wep
			
			if [ -z $wlan_key_id ]; then 
				wlan_key_id="1"
			fi
			/sbin/raconfig set $wlan_essid open wep $wlan_key_id $wlan_key
		elif [ $wlan_enc = 2 ]; then 
			# tkip
			/sbin/raconfig set $wlan_essid wpapsk tkip $wlan_key
		elif [ $wlan_enc = 3 ]; then 
			# aes
			/sbin/raconfig set $wlan_essid wpapsk aes $wlan_key
		fi
	fi

}

while [ 1 ]; do

	status=`/sbin/raconfig status`
	if [ $status != 0 ]; then
		wlan_connect
	fi
	/bin/sleep 2

done
