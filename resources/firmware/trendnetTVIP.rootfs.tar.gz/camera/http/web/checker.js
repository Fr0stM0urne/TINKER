var timezone_city=new Array(
		"(GMT-12:00) Eniwetok, Kwajalein",
		"(GMT-11:00) Midway Island, Samoa",
		"(GMT-10:00) Hawaii",
		"(GMT-10:00) Adak, Alaska",
		"(GMT-09:00) Alaska",
		"(GMT-08:00) Pacific Time(US & Canada)",
		"(GMT-08:00) Tijuana, Mexico",
		"(GMT-07:00) Mountain Time(US & Canada)",
		"(GMT-07:00) Chihuahua, La Paz, Mazatlan",
		"(GMT-07:00) Arizona; Sonora, Mexico",
		"(GMT-06:00) Creighton, Denare Beach",
		"(GMT-06:00) Saskatchewan",
		"(GMT-06:00) Guadalajara, Mexico City, Monterrey",
		"(GMT-06:00) Central Time(US & Canada)",
		"(GMT-05:00) Indiana(East)",
		"(GMT-05:00) Eastern Time(US & Canada)",
		"(GMT-05:00) Bogota, Lima, Quito",
		"(GMT-04:00) Santiago",
		"(GMT-04:00) Caracas, La Paz",
		"(GMT-04:00) Atlantic Time(Canada)",
		"(GMT-03:30) Newfoundland",
		"(GMT-03:00) Greenland",
		"(GMT-03:00) Buenos Aires, Georgetown",
		"(GMT-03:00) Brasilia",
		"(GMT-02:00) Mid-Atlantic",
		"(GMT-01:00) Cape Verde Is.",
		"(GMT-01:00) Azores",
		"(GMT) Greenwich Mean Time : Dublin, Edinburgh, Lisbon, London",
		"(GMT) Casablanca, Monrovia",
		"(GMT+01:00) Amsterdam, Berlin, Bern, Rome, Stockholm, Vienna",
		"(GMT+01:00) Belgrade, Bratislava, Budapest, Ljubljana, Prague",
		"(GMT+01:00) Brussels, Copenhagen, Madrid, Paris",
		"(GMT+01:00) Sarajevo, Skopje, Warsaw, Zagreb",
		"(GMT+02:00) Athens, Istanbul",
		"(GMT+02:00) Minsk",
		"(GMT+02:00) Bucharest",
		"(GMT+02:00) Cairo",
		"(GMT+02:00) Harare, Pretoria",
		"(GMT+02:00) Helsinki, Kyiv, Riga, Sofia, Tallinn, Vilnius",
		"(GMT+02:00) Jerusalem",
		"(GMT+03:00) Baghdad",
		"(GMT+03:00) Kuwait, Riyadh",
		"(GMT+03:00) Moscow, St. Petersburg, Volgograd",
		"(GMT+03:00) Nairobi",
		"(GMT+03:30) Tehran",
		"(GMT+04:00) Abu Dhabi, Muscat",
		"(GMT+04:00) Baku",
		"(GMT+04:00) Yerevan, Armenia",
		"(GMT+04:00) Tbilisi, Georgia",
		"(GMT+04:30) Kabul",
		"(GMT+05:00) Ekaterinburg",
		"(GMT+05:00) Islamabad, Karachi, Tashkent",
		"(GMT+05:30) Chennai, Kolkata, Mumbai, New Delhi",
		"(GMT+05:45) Kathmandu",
		"(GMT+06:00) Almaty",
		"(GMT+06:00) Novosibirsk",
		"(GMT+06:00) Astana, Dhaka",
		"(GMT+06:30) Rangoon",
		"(GMT+07:00) Bangkok, Hanoi, Jakarta",
		"(GMT+07:00) Krasnoyarsk",
		"(GMT+08:00) Beijing, Chongqing, Hong Kong, Urumqi",
		"(GMT+08:00) Irkutsk",
		"(GMT+08:00) Ulaan Bataar",
		"(GMT+08:00) Kuala Lumpur, Singapore",
		"(GMT+08:00) Perth",
		"(GMT+08:00) Taipei",
		"(GMT+09:00) Osaka, Sapporo, Tokyo",
		"(GMT+09:00) Seoul",
		"(GMT+09:00) Yakutsk",
		"(GMT+09:30) Adelaide",
		"(GMT+10:00) Brisbane",
		"(GMT+10:00) Canberra, Melbourne, Sydney",
		"(GMT+10:00) Guam, Port Moresby",
		"(GMT+10:00) Hobart",
		"(GMT+10:00) Vladivostok",
		"(GMT+11:00) Magadan",
		"(GMT+11:00) Solomon Is., New Caledonia",
		"(GMT+12:00) Auckland, Wellington",
		"(GMT+12:00) Fiji, Marshall Is.",
		"(GMT+12:00) Kamchatka"
	);

var dst_info=new Array(
		"000+12:00",
		"000+11:00",
		"000+10:00",
		"HADT+09:00,M03.2.0/02:00:00,M11.1.0/02:00:00",
		"AKDT+08:00,M03.2.0/02:00:00,M11.1.0/02:00:00",
		"PDT+07:00,M03.2.0/02:00:00,M11.1.0/02:00:00",
		"PDT+07:00,M04.1.0/02:00:00,M10.5.0/02:00:00",
		"MDT+06:00,M03.2.0/02:00:00,M11.1.0/02:00:00",
		"MDT+06:00,M04.1.0/02:00:00,M10.5.0/02:00:00",
		"000+07:00",
		"CDT+05:00,M03.2.0/02:00:00,M11.1.0/02:00:00",
		"000+06:00",
		"CDT+05:00,M04.1.0/02:00:00,M10.5.0/02:00:00",
		"CDT+05:00,M03.2.0/02:00:00,M11.1.0/02:00:00",
		"000+05:00",
		"EDT+04:00,M03.2.0/02:00:00,M11.1.0/02:00:00",
		"000+05:00",
		"CLST+03:00,M10.2.0/00:00:00,M03.2.0/00:00:00",
		"000+04:00",
		"ADT+03:00,M03.2.0/02:00:00,M11.1.0/02:00:00",
		"NDT+02:30,M03.2.0/00:01:00,M11.1.0/00:01:00",
		"WGST+02:00,M03.4.6/22:00:00,M10.4.6/23:00:00",
		"000+03:00",
		"BRST+02:00,M10.3.0/00:00:00,M02.5.0/00:00:00",
		"GMT+01:00,M03.4.6/22:00:00,M10.4.6/23:00:00",
		"000+01:00",
		"AZOST+0,M03.5.0/00:00:00,M10.5.0/01:00:00",
		"WEST-01:00,M03.5.0/01:00:00,M10.5.0/02:00:00",
		"000-0",
		"CEST-02:00,M03.5.0/02:00:00,M10.5.0/03:00:00",
		"CEST-02:00,M03.5.0/02:00:00,M10.5.0/03:00:00",
		"CEST-02:00,M03.5.0/02:00:00,M10.5.0/03:00:00",
		"CEST-02:00,M03.5.0/02:00:00,M10.5.0/03:00:00",
		"EEST-03:00,M03.5.0/03:00:00,M10.5.0/04:00:00",
		"EEST-03:00,M03.5.0/02:00:00,M10.5.0/03:00:00",
		"EEST-03:00,M03.5.0/03:00:00,M10.5.0/04:00:00",
		"EEST-03:00,M04.4.5/00:00:00,M09.1.5/00:00:00",
		"000-02:00",
		"EEST-03:00,M03.5.0/03:00:00,M10.5.0/04:00:00",
		"IDT-03:00,M03.5.5/02:00:00,M09.3.0/02:00:00",
		"ADT-04:00,M04.1.0/03:00:00,M10.1.1/04:00:00",
		"000-03:00",
		"MSD-04:00,M03.5.0/02:00:00,M10.5.0/03:00:00",
		"000-03:00",
		"000-03:30",
		"000-04:00",
		"AZST-05:00,M03.5.0/04:00:00,M10.5.0/05:00:00",
		"AMST-05:00,M03.5.0/02:00:00,M10.5.0/03:00:00",
		"000-04:00",
		"000-04:30",
		"YEKST-06:00,M03.5.0/02:00:00,M10.5.0/03:00:00",
		"000-05:00",
		"000-05:30",
		"000-05:45",
		"000-06:00",
		"NOVST-07:00,M03.5.0/02:00:00,M10.5.0/03:00:00",
		"000-06:00",
		"000-06:30",
		"000-07:00",
		"KRAST-08:00,M03.5.0/02:00:00,M10.5.0/03:00:00",
		"000-08:00",
		"IRKST-09:00,M03.5.0/02:00:00,M10.5.0/03:00:00",
		"000-08:00",
		"000-08:00",
		"WST-09:00,M10.5.0/02:00:00,M03.5.0/03:00:00",
		"000-08:00",
		"000-09:00",
		"000-09:00",
		"YAKST-10:00,M03.5.0/02:00:00,M10.5.0/03:00:00",
		"CST-10:30,M10.5.0/02:00:00,M03.5.0/03:00:00",
		"000-10:00",
		"EST-11:00,M10.5.0/02:00:00,M03.5.0/03:00:00",
		"000-10:00",
		"EST-11:00,M10.1.0/02:00:00,M04.1.0/03:00:00",
		"VLAST-11:00,M03.5.0/02:00:00,M10.5.0/03:00:00",
		"MAGST-12:00,M03.5.0/02:00:00,M10.5.0/03:00:00",
		"000-11:00",
		"NZDT-13:00,M09.5.0/02:00:00,M04.1.0/03:00:00",
		"000-12:00",
		"PETST-13:00,M03.5.0/02:00:00,M10.5.0/03:00:00"
	);

function errorRedirect(code){
	window.status="error code="+code;
	window.location="/error.asp";
}

function alertAndSelect(obj,str){
	alert(str);
	obj.select();
}


function isNUM(obj){
	for(i=0;i<obj.value.length;i++)
	  if(isNaN(obj.value.charAt(i)))
	  {  alertAndSelect(obj,"IP check - not a legal number: "+ obj.value)
             return false;
	  }
	return true;
}
function inRange(obj){
	if (range(obj.value,0,255)==false)
	{   alertAndSelect(obj,"IP check - ip exceeds range: " + obj.value);
	     return false;
	}
	return true;
}

function isFilled(obj){
	if(obj.value=="")
	{	alertAndSelect(obj,"IP check - ip field can't be blank");
		return false;
	}
	return true
}

function isPosInt(num){
	re = /^\d+$/;
	if (!re.test(num)) 
		return false;
	return true;
}

function trimHTblank(s){
 // Remove leading spaces 

  while (s.substring(0,1) == ' ') 
  {
    s = s.substring(1,s.length);
  }

  // Remove trailing spaces

  while (s.substring(s.length-1,s.length) == ' ') 
  {
    s = s.substring(0,s.length-1);
  }
  return s;

}


function ipCheck(a,b,c,d){
	if(!isNUM(a))	return -1;
	if(!isNUM(b))	return -1;
	if(!isNUM(c))   return -1;
	if(!isNUM(d)) 	return -1;
	if(!inRange(a))	return -2;
	if(!inRange(b))	return -2;
	if(!inRange(c))	return -2;
	if(!inRange(d))	return -2;
	if(((a.value=="")&&(b.value=="")&&(c.value=="")&&(d.value==""))==false)
	{
	 
	 if(!isFilled(a))return -3;	
	 if(!isFilled(b))return -3;
	 if(!isFilled(c))return -3;
	 if(!isFilled(d))return -3;
	}
	return true;
}

function dateCheck(obj){

	obj.value=trimHTblank(obj.value);
	a=obj.value.split("-");
	if(( isPosInt(a[0]) && isPosInt(a[1]) && isPosInt(a[2]) ) == false)
	{	alertAndSelect(obj,"illegal date input");
		return false;
	}
	if(range(a[0],1970,2037)==false)
	{	alertAndSelect(obj,"year exceeds range (1970-2037)");
		return false;
	}
	
	if(isValidDate(a[2],a[1],a[0])==false)
	{	alertAndSelect(obj, "\'" +obj.value+ "\' is not a correct date");
		return false;
	}	
	obj.value=a[0]+"-"+addzero(trimzero(a[1]))+"-"+addzero(trimzero(a[2]));
	return true;
}

function isValidDate(day,month,year){
var dteDate;
dteDate=new Date(year,month-1,day);
 return(	(day==dteDate.getDate()) && ((month-1)==dteDate.getMonth()) && (year==dteDate.getFullYear()))
  
}




function timeCheck(obj){

	obj.value=trimHTblank(obj.value);
	a=obj.value.split(":");
	if(( isPosInt(a[0]) && isPosInt(a[1]) && isPosInt(a[2]) ) == false)
	{	
		alertAndSelect(obj,"illegal time input");
		return false;
	}

	if(range(a[0],0,23)==false)
	{	alertAndSelect(obj,"hour exceeds range");
		return false;
	}
	if(range(a[1],0,59)==false)
	{	alertAndSelect(obj,"minute exceeds range");
		return false;
	}
	if(range(a[2],0,59)==false)
	{	alertAndSelect(obj,"second exceeds range");
		return false;
	}
	obj.value=addzero(trimzero(a[0]))+":"+addzero(trimzero(a[1]))+":"+addzero(trimzero(a[2]));


	return true;
}

function timeCheck2(obj1,obj2,obj3){

	if((isPosInt(obj1.value)&&range(obj1.value,0,23))==false)
	{	alertAndSelect(obj1,"hour not valid");
		return false;
	}
	if((isPosInt(obj2.value)&&range(obj2.value,0,59))==false)
	{	alertAndSelect(obj2,"minute not valid");
		return false;
	}
	if((isPosInt(obj3.value)&&range(obj3.value,0,59))==false)
	{	alertAndSelect(obj3,"second not valid");
		return false;
	}
	return true;
}
function emailCheck(obj){
	//var filter="^[\\w-_\.]*[\\w-_\.]\@[\\w]\.+[\\w]+[\\w]$";
	var filter=/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i
	if ((filter.test(obj.value)==false) && (obj.value!=""))
	{
		alertAndSelect(obj,"email not valid");
		return false;
	}
	return true;
	
}

function domainCheck(obj){
	
	var filter=/((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
	//var filterip=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/ 
	if ((filter.test(obj.value)==false) && (obj.value!="") && (isValidIP(obj.value)==false))
	{
		alertAndSelect(obj,"domain not valid");
		return false;
	}
	return true;

}

function hostnameCheck(obj){
	if(isValidString(obj.value,"\\~!@#$%^&*()=+/|{}[]<>,:;`\'\"?.")==false)
	{
		alertAndSelect(obj,"camera name can only contains '-','_',[a-z],[A-Z],[0-9]");
		return false;
	}
	if(isValidString(obj.value," ")==false)
	{
		alertAndSelect(obj,"camera name cannot contains space");
		return false;
	}

	if(isPosInt(obj.value))
	{
		alertAndSelect(obj,"camera name cannot be a number");
		return false;
	}
	return true;

}

//obj:  the obj to be checked
//bit:  64bit ==0 , 128bit ==1
//enc:  Ascii ==0 ,   Hex == 1
function wepCheck(obj,bit,enc){
	var filter ;
	var validLength;
	if((bit == 0)&&(enc == 0))
		validLength = 5
	else if((bit == 0)&&(enc == 1))
		validLength = 10
	else if((bit == 1)&&(enc == 0))
		validLength = 13
	else if((bit == 1)&&(enc == 1))
		validLength = 26

	if(enc==0)
		filter = /^[a-zA-Z0-9]+$/;
	else if(enc==1)
		filter = /^[a-fA-F0-9]+$/;

	if(obj.value.length != validLength)
	{
		alertAndSelect(obj,"this key should be " + validLength+" charecters long");
		return false;
	}
	if(filter.test(obj.value)==false)
	{
		if(enc==0)
			alertAndSelect(obj,"ascii key should only contains [a-z],[A-Z],[0-9]");
		else if(enc==1)
			alertAndSelect(obj,"hex key should only contains [a-f],[A-f],[0-9]");
		return false;
	}
	
	return true;
	
}

function asciiCheck(value){
	var i;
	for(i=0;i<value.length();i++){
		if(isNaN()){}
	}
}
function hexCheck(value){
}

function essidCheck(obj){
	if(isValidString(obj.value,"\\~!@#$%^&*()=+/|{}[]<>,:;`\'\"?.")==false)
	{
		alertAndSelect(obj,"essid can only contains [a-z],[A-Z],[0-9],-,_");
		return false;
	}

	if(isValidString(obj.value," ")==false)
	{
		alertAndSelect(obj,"essid cannot contains space");
		return false;
	}
	return true;
	
}

function textCheck(obj){
	if(isValidString(obj.value,"\"") == false)
	{
		alertAndSelect(obj,"can't contain symbol \" ");
		return false;
	}
	return true

}

function pathCheck(obj){
	if(isValidString(obj.value,"\\")==false)
	{
		alertAndSelect(obj,"path should use slash \'/\'");
		return false;
	}
	return true;
}

function isValidIP(str) {
   var re = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
   if (re.test(str)) {
      var parts = str.split(".");
      if (parseInt(parseFloat(parts[0])) == 0) { return false; }
      for (var i=0; i<parts.length; i++) {
         if (parseInt(parseFloat(parts[i])) > 255) { return false; }
      }
      return true;
   } else {
      return false;
   }
}


function intervalCheck(obj,minint,maxint){
	re = /^\d+$/;
	if (isPosInt(obj.value)==false) {
		alertAndSelect(obj,"\'"+ obj.value + '\' is NOT an positive integer!');
		return false;
	}
	if(range(obj.value,minint,maxint)==false){
	alertAndSelect(obj, "\'" + obj.value + '\' exceeds range  [ '+ minint + '-' + maxint + ']');
		return false;
	}
	return true;
	
}


function filenameCheck(obj){
	if((isValidString(obj.value,"\\/:*?\"<>|") )==false)
	{
		alertAndSelect(obj,"\'"+ obj.value + '\' is NOT a valid name!' +"(contains   \\:/*?\"<>|)");
		return false;
	}
	return true;
}


function isContainsInvalid(oriStr,InvalidChars)
{

   var IsValid=false;
   var Char;

 
   for (i = 0; i < oriStr.length && IsValid == true; i++) 
      { 
      Char = oriStr.charAt(i); 
      if (InvalidChars.indexOf(Char) != -1) 
         {
         IsValid = true;
         }
      }
   return IsValid;
   
}


function isValidString(oriStr,InvalidChars)
{

   var IsValid=true;
   var Char;

 
   for (i = 0; i < oriStr.length && IsValid == true; i++) 
      { 
      Char = oriStr.charAt(i); 
      if (InvalidChars.indexOf(Char) != -1) 
         {
         IsValid = false;
         }
      }
   return IsValid;
   
}





function parstIntTrimZero(strobj){
	i=0;
//	alert("type=" +typeof(str.length) + "   value =" + str.length);
//	alert("type=" +typeof(str) + "   value =" + str);
//	t="abc"
//	alert("type=" +typeof(t) + "   value =" + t);
//	alert("type=" +typeof(t.length) + "    value =" + t.length);
	var str = new String(strobj);
	while ((str.substring(i,i+1)=="0")&&(i<str.length-1))
	     i++;
//	alert("i=" + i + "typeof(" + typeof(i) +")" )
//	tlength=str.length;
//	alert(typeof(tlength));
//	tstr=str.substring(i,tlength);
	return parseInt(str.substring(i,str.length))
	
}

function range(value,min,max){
	return ((value<min)||(value>max))?false:true;
}

function addzero(num){
	if(num<=9)
	  return "0"+num 
	else
	  return num
}

function trimzero(strobj){
	i=0;
	var str = new String(strobj);
	while ((str.substring(i,i+1)=="0")&&(i<str.length-1))
	     i++;
	return str.substring(i,str.length)
}

function addTrailSlash(s){
	if(s.substring(s.length-1,s.length) != "\\")
		s=s+"\\";
	return s
}

function getRadioCheckedIndex(radioObject){
	var value=0;
	for (i=0;i<radioObject.length;i++){
		if (radioObject[i].checked)
		   return i
	}
}

function setRadioByArray(radioObject,inputArray,inputString){
	for(i=0;i<inputArray.length;i++)
	  if(inputString==inputArray[i])
	  	{radioObject[i].checked=true
	  	break
	  	}
}


function getArrayIndex(radioObject,inputArray,inputString){
	for(i=0;i<inputArray.length;i++)
	  if(inputString==inputArray[i])
		return i;
	return 0;
}

function applydst(city){
	var dstinfo = "";
	for(i=0; i<timezone_city.length; i++){
		if(city==timezone_city[i]){
			dstinfo = dst_info[i];
			break;
		}
	}
	if(dstinfo != ""){
		if(dstinfo.substring(0,3)!="000")
			return 1;
	}
	return 0;
}

function resetIDrange(chooser,order){

	var DevIDmax = new Object( )
	DevIDmax[0] = [255];    //Pelco-D
	DevIDmax[1] = [64];     //Lilin
	DevIDmax[2] = [223];    //Dyna
	DevIDmax[3] = [32];     //Pelco-P

	var newElem;
	var where = (navigator.appName == "Microsoft Internet Explorer") ? -1 : null;
	var devidChooser = chooser.form.elements["f_DevID"];
	while(devidChooser.options.length){
		devidChooser.remove(0);
	}
	var pro_model = chooser.options[chooser.selectedIndex].value;
	var idmax = DevIDmax[pro_model];
	if(pro_model != -1){
		for (var i = 1; i <= idmax[0]; i++) {
			newElem = document.createElement("option");
			newElem.text = i;
			newElem.value = i;
			devidChooser.add(newElem, where);
                }
        }
}


